
import React from 'react';
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ArrowRight, Star, Book, Code, User, Gamepad, Music, Film, Monitor } from "lucide-react";
import AnimatedText from "@/components/AnimatedText";
import SkillBadge from "@/components/SkillBadge";
import ProjectCard from "@/components/ProjectCard";
import SectionTitle from "@/components/SectionTitle";
import ContactForm from "@/components/ContactForm";
import Navbar from "@/components/Navbar";
import { useLanguage } from '@/contexts/LanguageContext';

const Index = () => {
  const isMobile = useIsMobile();
  const { t } = useLanguage();

  const skills = [
    { name: "HTML/CSS", level: 5 },
    { name: "JavaScript", level: 5 },
    { name: "PHP", level: 4 },
    { name: "WordPress", level: 4 },
    { name: "MySQL", level: 4 },
    { name: "Adobe Suite", level: 5 },
    { name: "D3.js", level: 4 },
    { name: "Microsoft Office", level: 4 }
  ];
  
  const projects = [
    {
      title: "Reservation Website",
      description: "Development of a reservation website using PHP, JavaScript, HTML and CSS.",
      image: "https://source.unsplash.com/photo-1581091226825-a6a2a5aee158",
      technologies: ["PHP", "JavaScript", "HTML", "CSS"],
      demoLink: "#",
      codeLink: "#"
    },
    {
      title: "Interactive Website",
      description: "Development of an interactive website using HTML, CSS and JavaScript.",
      image: "https://source.unsplash.com/photo-1486312338219-ce68d2c6f44d",
      technologies: ["HTML", "CSS", "JavaScript"],
      demoLink: "#",
      codeLink: "#"
    },
    {
      title: "Data Visualization",
      description: "Creation of a data visualization site using HTML, CSS, D3.js and SCV.",
      image: "https://source.unsplash.com/photo-1488590528505-98d2b5aba04b",
      technologies: ["HTML", "CSS", "D3.js", "SCV"],
      demoLink: "#",
      codeLink: "#"
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32 flex items-center">
        <div className="absolute inset-0 bg-gradient-radial from-anime-purple/10 to-transparent -z-10"></div>
        <div className="container px-4 mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-10">
            <div className="flex-1 text-center md:text-left">
              <p className="text-anime-purple font-medium mb-2 animate-fade-in">{t('welcomeText')}</p>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                <AnimatedText 
                  text={t('heroTitle')}
                  className="inline animate-slide-in"
                  delay={100}
                />
                <AnimatedText 
                  text={t('heroName')}
                  className="inline anime-heading"
                  delay={400}
                />
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-muted-foreground max-w-xl mx-auto md:mx-0">
                <AnimatedText 
                  text={t('heroSubtitle')}
                  delay={700}
                />
              </p>
              <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                <Button asChild className="anime-button">
                  <a href="#projects">
                    {t('viewProjects')}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </Button>
                <Button asChild variant="outline" className="border-anime-purple text-anime-purple hover:bg-anime-purple/10">
                  <a href="#contact">{t('contactMe')}</a>
                </Button>
              </div>
            </div>
            <div className="flex-1 flex justify-center">
              <div className="w-64 h-64 md:w-80 md:h-80 relative animate-float">
                {/* Replace with your anime-style avatar or illustration */}
                <div className="rounded-full bg-gradient-to-br from-anime-purple to-anime-pink p-1 animate-pulse-glow">
                  <div className="rounded-full bg-white dark:bg-gray-800 p-2 h-full w-full flex items-center justify-center">
                    <User className="h-32 w-32 md:h-40 md:w-40 text-anime-purple" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* About Section */}
      <section id="about" className="py-20 bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm">
        <div className="section-container">
          <SectionTitle 
            title={t('aboutTitle')}
            subtitle={t('aboutSubtitle')}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="prose max-w-none dark:prose-invert">
              <p className="text-lg">
                {t('aboutText1')}
              </p>
              <p className="text-lg mt-4">
                {t('aboutText2')}
              </p>
              <p className="text-lg mt-4">
                {t('aboutText3')}
              </p>
            </div>
            
            <div className="flex flex-col space-y-6">
              <div className="flex items-start space-x-4">
                <span className="bg-anime-purple/10 p-3 rounded-full">
                  <Star className="h-6 w-6 text-anime-purple" />
                </span>
                <div>
                  <h3 className="font-bold text-xl">{t('experience')}</h3>
                  <p>{t('experienceText')}</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <span className="bg-anime-pink/10 p-3 rounded-full">
                  <Book className="h-6 w-6 text-anime-pink" />
                </span>
                <div>
                  <h3 className="font-bold text-xl">{t('education')}</h3>
                  <p>{t('educationText')}</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <span className="bg-anime-blue/10 p-3 rounded-full">
                  <Code className="h-6 w-6 text-anime-blue" />
                </span>
                <div>
                  <h3 className="font-bold text-xl">{t('passionProjects')}</h3>
                  <p>{t('passionProjectsText')}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Skills Section */}
      <section id="skills" className="py-20">
        <div className="section-container">
          <SectionTitle 
            title={t('skillsTitle')}
            subtitle={t('skillsSubtitle')}
          />
          
          <div className="flex flex-wrap gap-3 justify-center">
            {skills.map((skill, index) => (
              <SkillBadge 
                key={skill.name} 
                name={skill.name} 
                level={skill.level} 
                className="mb-4"
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Projects Section */}
      <section id="projects" className="py-20 bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm">
        <div className="section-container">
          <SectionTitle 
            title={t('projectsTitle')}
            subtitle={t('projectsSubtitle')}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <ProjectCard 
                key={index}
                title={project.title}
                description={project.description}
                image={project.image}
                technologies={project.technologies}
                demoLink={project.demoLink}
                codeLink={project.codeLink}
              />
            ))}
          </div>
        </div>
      </section>
      
      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="section-container">
          <SectionTitle 
            title={t('contactTitle')}
            subtitle={t('contactSubtitle')}
          />
          
          <div className="max-w-2xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
      
      {/* Interests Section */}
      <section className="py-16 bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm">
        <div className="section-container">
          <SectionTitle 
            title="Centre d'intérêt"
            subtitle="What I enjoy in my free time"
          />
          
          <div className="flex justify-center gap-8 mt-8">
            <div className="flex flex-col items-center">
              <Gamepad className="h-12 w-12 text-anime-purple mb-2" />
              <p>Gaming</p>
            </div>
            <div className="flex flex-col items-center">
              <Music className="h-12 w-12 text-anime-pink mb-2" />
              <p>Music</p>
            </div>
            <div className="flex flex-col items-center">
              <Book className="h-12 w-12 text-anime-blue mb-2" />
              <p>Reading</p>
            </div>
            <div className="flex flex-col items-center">
              <Monitor className="h-12 w-12 text-anime-purple mb-2" />
              <p>Multimedia</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-8 bg-anime-dark text-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="mb-4 md:mb-0">{t('copyright')}</p>
            <div className="flex space-x-6">
              <a href="#" className="hover:text-anime-purple transition-colors">GitHub</a>
              <a href="#" className="hover:text-anime-purple transition-colors">LinkedIn</a>
              <a href="#" className="hover:text-anime-purple transition-colors">Twitter</a>
              <a href="#" className="hover:text-anime-purple transition-colors">Instagram</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
