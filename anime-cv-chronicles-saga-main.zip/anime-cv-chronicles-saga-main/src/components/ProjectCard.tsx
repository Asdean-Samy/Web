
import { FC } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Code, Link } from "lucide-react";

interface ProjectCardProps {
  title: string;
  description: string;
  image: string;
  technologies: string[];
  demoLink?: string;
  codeLink?: string;
}

const ProjectCard: FC<ProjectCardProps> = ({ 
  title, 
  description, 
  image, 
  technologies,
  demoLink, 
  codeLink 
}) => {
  return (
    <Card className="anime-card h-full flex flex-col">
      <div className="h-48 overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" 
        />
      </div>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <div className="flex flex-wrap gap-2">
          {technologies.map((tech, index) => (
            <span 
              key={index} 
              className="text-xs bg-secondary px-2 py-1 rounded-full"
            >
              {tech}
            </span>
          ))}
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <CardDescription>{description}</CardDescription>
      </CardContent>
      <CardFooter className="flex gap-2">
        {demoLink && (
          <Button asChild variant="default" className="flex-1">
            <a href={demoLink} target="_blank" rel="noopener noreferrer">
              <Link className="mr-2 h-4 w-4" />
              Demo
            </a>
          </Button>
        )}
        {codeLink && (
          <Button asChild variant="outline" className="flex-1">
            <a href={codeLink} target="_blank" rel="noopener noreferrer">
              <Code className="mr-2 h-4 w-4" />
              Code
            </a>
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default ProjectCard;
