
import { FC } from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import ThemeToggle from './ThemeToggle';
import LanguageSwitcher from './LanguageSwitcher';
import { useLanguage } from '@/contexts/LanguageContext';

interface NavbarProps {
  className?: string;
}

const Navbar: FC<NavbarProps> = ({ className }) => {
  const { language, t } = useLanguage();
  
  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border-b border-anime-purple/10">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex items-center">
          <Link to="/" className="font-display text-2xl text-anime-purple">Asdean Samy</Link>
        </div>
        <nav className="flex items-center justify-between w-full">
          <div className="hidden md:flex gap-6 items-center">
            <a href="#about" className="text-foreground hover:text-anime-purple transition-colors">
              {language === 'en' ? 'About' : 'À Propos'}
            </a>
            <a href="#skills" className="text-foreground hover:text-anime-purple transition-colors">
              {language === 'en' ? 'Skills' : 'Compétences'}
            </a>
            <a href="#projects" className="text-foreground hover:text-anime-purple transition-colors">
              {language === 'en' ? 'Projects' : 'Projets'}
            </a>
            <a href="#contact" className="text-foreground hover:text-anime-purple transition-colors">
              {language === 'en' ? 'Contact' : 'Contact'}
            </a>
          </div>
          <div className="flex items-center gap-3">
            <LanguageSwitcher />
            <ThemeToggle />
            <Button className="anime-button">{t('downloadCV')}</Button>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
