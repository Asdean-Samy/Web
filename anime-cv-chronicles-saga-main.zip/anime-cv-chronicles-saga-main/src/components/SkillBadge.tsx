
import { FC } from 'react';
import { cn } from '@/lib/utils';

interface SkillBadgeProps {
  name: string;
  level?: number;
  className?: string;
}

const SkillBadge: FC<SkillBadgeProps> = ({ name, level = 0, className }) => {
  const levelColors = [
    'bg-gray-200 text-gray-700',
    'bg-blue-100 text-blue-700',
    'bg-green-100 text-green-700',
    'bg-yellow-100 text-yellow-700',
    'bg-anime-purple text-white'
  ];
  
  const levelColor = level >= 1 && level <= 5 ? levelColors[level-1] : levelColors[0];
  
  return (
    <span 
      className={cn(
        "inline-block px-4 py-2 rounded-full text-sm font-semibold animate-float",
        levelColor,
        className
      )}
    >
      {name}
    </span>
  );
};

export default SkillBadge;
