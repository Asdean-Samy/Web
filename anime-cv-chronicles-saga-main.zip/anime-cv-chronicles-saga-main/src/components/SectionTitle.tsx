
import { FC } from 'react';
import { cn } from '@/lib/utils';

interface SectionTitleProps {
  title: string;
  subtitle?: string;
  className?: string;
}

const SectionTitle: FC<SectionTitleProps> = ({ title, subtitle, className }) => {
  return (
    <div className={cn("text-center mb-12", className)}>
      <h2 className="anime-heading text-3xl md:text-4xl lg:text-5xl font-bold mb-4">{title}</h2>
      {subtitle && <p className="text-muted-foreground max-w-2xl mx-auto">{subtitle}</p>}
      <div className="mt-4 flex justify-center">
        <div className="h-1 w-20 bg-gradient-to-r from-anime-purple to-anime-pink rounded-full"></div>
      </div>
    </div>
  );
};

export default SectionTitle;
