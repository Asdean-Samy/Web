
import { FC } from 'react';
import { cn } from '@/lib/utils';

interface AnimatedTextProps {
  text: string;
  className?: string;
  delay?: number;
}

const AnimatedText: FC<AnimatedTextProps> = ({ text, className, delay = 0 }) => {
  return (
    <span 
      className={cn("inline-block animate-slide-in opacity-0", className)}
      style={{ animationDelay: `${delay}ms`, animationFillMode: 'forwards' }}
    >
      {text}
    </span>
  );
};

export default AnimatedText;
