
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useLanguage } from "@/contexts/LanguageContext";
import { Globe } from "lucide-react";

const LanguageSwitcher = () => {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center">
      <Globe className="mr-2 h-4 w-4 text-muted-foreground" />
      <ToggleGroup type="single" value={language} onValueChange={(value) => value && setLanguage(value as 'en' | 'fr')}>
        <ToggleGroupItem value="en" aria-label="English" className="text-xs h-8">
          EN
        </ToggleGroupItem>
        <ToggleGroupItem value="fr" aria-label="French" className="text-xs h-8">
          FR
        </ToggleGroupItem>
      </ToggleGroup>
    </div>
  );
};

export default LanguageSwitcher;
