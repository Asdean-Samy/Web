
import { Moon, Sun } from "lucide-react";
import { Toggle } from "@/components/ui/toggle";
import { useTheme } from "@/contexts/ThemeContext";

const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <Toggle
      pressed={theme === "dark"}
      onPressedChange={toggleTheme}
      aria-label="Toggle dark mode"
      className="hover:bg-muted"
    >
      {theme === "dark" ? (
        <Moon className="h-5 w-5 text-yellow-200" />
      ) : (
        <Sun className="h-5 w-5 text-yellow-500" />
      )}
      <span className="sr-only">{theme === "dark" ? "Light mode" : "Dark mode"}</span>
    </Toggle>
  );
};

export default ThemeToggle;
