
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define language types
type Language = 'en' | 'fr';

// Define translation data
const translations = {
  en: {
    welcomeText: "Welcome to my portfolio",
    heroTitle: "Hi, I'm ",
    heroName: "Asdean Samy Bouzenad",
    heroSubtitle: "Web Developer specializing in creating engaging digital experiences",
    viewProjects: "View Projects",
    contactMe: "Contact Me",
    aboutTitle: "About Me",
    aboutSubtitle: "Learn more about my background and what drives me",
    aboutText1: "My training in digital technology has provided me with skills in web development and digital creation. I'm curious and involved, enjoy teamwork, and like to take on challenges.",
    aboutText2: "My logical mind and creativity help me solve problems. I'm looking to strengthen my skills and gain concrete experience in web development.",
    aboutText3: "When I'm not coding, you can find me exploring new technologies and working on creative projects.",
    experience: "Experience",
    experienceText: "2021-2024: Receptionist at Hôtel ANYA (Customer service and reservation management). 2021: Internship at Tabaskko/Highfun (Video editing on Premiere Pro).",
    education: "Education",
    educationText: "2023: BUT - Gustave Eiffel | Champ sur Marne, MMI (Multimedia and Internet Professions). 2021-2023: Prépa Licence - Pierre Marie Curie | Paris, Sciences Formelles. 2019-2021: Baccalauréat - Henri Bergson | Paris, STI2D.",
    passionProjects: "Certifications",
    passionProjectsText: "Opquast - Focus on integrating rules and vocabulary for web quality assurance in professional practice.",
    skillsTitle: "My Skills",
    skillsSubtitle: "Technologies and tools I work with",
    projectsTitle: "My Projects",
    projectsSubtitle: "Check out my latest work",
    contactTitle: "Get In Touch",
    contactSubtitle: "Have a project in mind or just want to chat? Feel free to contact me!",
    copyright: "© 2025 Asdean Samy Bouzenad. All rights reserved.",
    downloadCV: "Download CV",
  },
  fr: {
    welcomeText: "Bienvenue sur mon portfolio",
    heroTitle: "Salut, je suis ",
    heroName: "Asdean Samy Bouzenad",
    heroSubtitle: "Développeur web spécialisé dans la création d'expériences numériques captivantes",
    viewProjects: "Voir les Projets",
    contactMe: "Me Contacter",
    aboutTitle: "À Propos de Moi",
    aboutSubtitle: "En savoir plus sur mon parcours et ce qui me motive",
    aboutText1: "Ma formation en numérique m'a apporté des compétences en développement web et en création numérique. Curieux et impliqué, j'aime le travail en équipe et relever des défis.",
    aboutText2: "Mon esprit logique et ma créativité m'aident à résoudre les problèmes. Je cherche à renforcer mes compétences et acquérir une expérience concrète en développement web.",
    aboutText3: "Quand je ne code pas, vous pouvez me trouver en train d'explorer de nouvelles technologies et de travailler sur des projets créatifs.",
    experience: "Expérience",
    experienceText: "2021-2024: Réceptionniste à l'Hôtel ANYA (Accueil et relation client, gestion des réservations). 2021: Stage Découverte chez Tabaskko/Highfun (Montage vidéo sur Première Pro).",
    education: "Éducation",
    educationText: "2023: BUT - Gustave Eiffel | Champ sur Marne, MMI (Métiers du Multimédia et de l'Internet). 2021-2023: Prépa Licence - Pierre Marie Curie | Paris, Sciences Formelles. 2019-2021: Baccalauréat - Henri Bergson | Paris, STI2D.",
    passionProjects: "Certifications",
    passionProjectsText: "Opquast - L'objectif est d'intégrer les règles et le vocabulaire assurance qualité web dans la pratique professionnelle.",
    skillsTitle: "Mes Compétences",
    skillsSubtitle: "Technologies et outils avec lesquels je travaille",
    projectsTitle: "Mes Projets",
    projectsSubtitle: "Découvrez mes derniers travaux",
    contactTitle: "Contactez-Moi",
    contactSubtitle: "Vous avez un projet en tête ou vous voulez simplement discuter ? N'hésitez pas à me contacter !",
    copyright: "© 2025 Asdean Samy Bouzenad. Tous droits réservés.",
    downloadCV: "Télécharger CV",
  }
};

// Define context type
interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations.en) => string;
}

// Create the context
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Context provider component
export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  // Initialize with browser language or default to English
  const [language, setLanguage] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('language');
    return (savedLanguage === 'fr' ? 'fr' : 'en') as Language;
  });

  // Save language preference to localStorage
  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  // Translation function
  const t = (key: keyof typeof translations.en): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use the language context
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
